# MCMS WP PLUGIN
A plugin for Wordpress that allows you to use the MCMS API to create and manage your content.

It exposes several REST endpoints that allow you to create, update, delete and retrieve content for your Astro site.

It all allows you to manage deployments on the Cloudflare Pages platform.

## Installation
1. Download the plugin
2. Upload it to your Wordpress site
3. Activate it
4. Go to the settings page and enter the settings of your Astro site